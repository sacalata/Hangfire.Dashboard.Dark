﻿using System;
using System.Collections.Generic;
using System.Threading;
using Opc.Ua;
using Opc.Ua.Server;
using OPCimpl;

namespace DaVinciOPCUA_Server
{
    //internal class MockNodeManager : SimpleNodeManager
    //{
    //    private List<BaseDataVariableState<bool>> fakeStation_IN1_List = new List<BaseDataVariableState<bool>>();
    //    private List<BaseDataVariableState<int>> fakeStation_Temp_List = new List<BaseDataVariableState<int>>();
    //    private List<BaseDataVariableState<string>> fakeStation_String_List = new List<BaseDataVariableState<string>>();
    //    private List<Timer> _updateTimers = new List<Timer>();
    //    private Random _random = new Random();
    //    private bool nodesCreated = false;
    //    private int lineCount;
    //    private int stationCount;
    //    private int timerInterval;
    //    private int minTemp;
    //    private int maxTemp;

    //    public MockNodeManager(IServerInternal server, ApplicationConfiguration configuration, int lineCount, int stationCount, int timerInterval, int minTemp, int maxTemp)
    //        : base(server, configuration)
    //    {
    //        this.lineCount = lineCount;
    //        this.stationCount = stationCount;
    //        this.timerInterval = timerInterval;
    //        this.minTemp = minTemp;
    //        this.maxTemp = maxTemp;
    //    }

    //    public override void CreateAddressSpace(IDictionary<NodeId, IList<IReference>> externalReferences)
    //    {
    //        base.CreateAddressSpace(externalReferences);

    //        // Get root node
    //        var root = CreateFolder("Machines");

    //        for (int i = 1; i <= lineCount; i++)
    //        {
    //            var line = CreateFolder($"BE{i:D2}", root);

    //            for (int j = 1; j <= stationCount; j++)
    //            {
    //                var fakeStation = CreateFolder($"MA{j:D2}", line);

    //                var fakeStation_Temp = CreateVariable(fakeStation, "TemperatureCelsius", 23);
    //                var fakeStation_IN1 = CreateVariable(fakeStation, "Active", false);
    //                var fakeStation_String = CreateVariable(fakeStation, "Status", "Initial");

    //                fakeStation_IN1_List.Add(fakeStation_IN1);
    //                fakeStation_Temp_List.Add(fakeStation_Temp);
    //                fakeStation_String_List.Add(fakeStation_String);
    //            }
    //        }

    //        nodesCreated = true;
    //        StartUpdatingNodes();
    //    }


    //    public void StartUpdatingNodes()
    //    {
    //        for (int i = 0; i < (stationCount * lineCount); i++)
    //        {
    //            var timer = new Timer(UpdateNode, i, TimeSpan.Zero, TimeSpan.FromSeconds(timerInterval));
    //            _updateTimers.Add(timer);
    //        }
    //        Console.WriteLine($"Started updating values every {timerInterval} seconds");
    //    }

    //    private void UpdateNode(object state)
    //    {
    //        if (!nodesCreated) return;

    //        int index = (int)state;
    //        var fakeStation_IN1 = fakeStation_IN1_List[index];
    //        var fakeStation_Temp = fakeStation_Temp_List[index];
    //        var fakeStation_String = fakeStation_String_List[index];

    //        // Toggle the sensor state
    //        fakeStation_IN1.Value = !fakeStation_IN1.Value;
    //        fakeStation_IN1.UpdateChangeMasks(NodeStateChangeMasks.Value);

    //        // Update the temperature with a random value within the specified range
    //        fakeStation_Temp.Value = _random.Next(minTemp, maxTemp + 1);
    //        fakeStation_Temp.UpdateChangeMasks(NodeStateChangeMasks.Value);

    //        // Update the string node with a new value
    //        fakeStation_String.Value = $"Updated at {DateTime.UtcNow}";
    //        fakeStation_String.UpdateChangeMasks(NodeStateChangeMasks.Value);

    //        // Notify clients
    //        fakeStation_IN1.ClearChangeMasks(SystemContext, false);
    //        fakeStation_Temp.ClearChangeMasks(SystemContext, false);
    //        fakeStation_String.ClearChangeMasks(SystemContext, false);
    //    }
    //}
}
